const should = require('chai').should();
const supertest = require('supertest');
const HTTPServer = require('../../lib/httpServer');

describe('HTTPServer', async () => {

    const createContext = async () => {
        const server = new HTTPServer();
        return {
            server
        };
    };

    it('should ping', async () => {
        const context = await createContext();
        return await supertest(context.server.app)
            .get('/ping')
            .expect(200);
    });

    it('should upload a file', async () => {
        const context = await createContext();
        const result = await supertest(context.server.app)
            .post('/artifacts')
            .field('name', 'name')
            .attach('artifact', './file.zip')
            .expect(200);
        result.body.should.be.an('object');
    });
});